import React from "react";
import Navigation from "./Components/Navigation";
import Container1 from "./Components/Container1";
import Central from "./Components/Central";
import Test from "./Components/test";

const App = () => {
  return (
    <>
      <Navigation />
      {/* <Container1 /> */}
      {/* <Central /> */}
      <Test />
    </>
  );
};

export default App;
