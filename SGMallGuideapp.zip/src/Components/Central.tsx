import React from 'react'

const Central = () => {
  const CentralMallsList = [
    {
      id: 1,
      name: "Aperia Mall",
      link: "https://www.capitaland.com/sg/malls/aperia/en.html",
      pic: "./assets/CLmall1.png",
    },
    {
      id: 2,
      name: "Bedok Mall",
      link: "https://www.capitaland.com/sg/malls/bedokmall/en.html",
      pic: "./assets/CLmall2.png",
    },
    {
      id: 3,
      name: "Bugis Junction",
      link: "https://www.capitaland.com/sg/malls/bugisjunction/en.html",
      pic: "./assets/CLmall3.png",
    },
    {
      id: 4,
      name: "Bugic Plus",
      link: "https://www.capitaland.com/sg/malls/bugisplus/en.html",
      pic: "./assets/CLmall4.png",
    },
    {
      id: 5,
      name: "Bugis Street",
      link: "https://www.capitaland.com/sg/malls/bugis-street/en.html",
      pic: "./assets/CLmall5.png",
    },
    {
      id: 6,
      name: "Bukit Panjang Plaza",
      link: "https://www.capitaland.com/sg/malls/bukitpanjangplaza/en.html",
      pic: "./assets/CLmall6.png",
    },
    {
      id: 7,
      name: "Clarke Quay",
      link: "https://www.capitaland.com/sg/malls/clarkequay/en.html",
      pic: "./assets/CLmall7.png",
    },
    {
      id: 8,
      name: "Funan Mall",
      link: "https://www.capitaland.com/sg/malls/funan/en.html",
      pic: "./assets/CLmall8.png",
    },
    {
      id: 9,
      name: "IMM Mall",
      link: "https://www.capitaland.com/sg/malls/imm/en.html",
      pic: "./assets/CLmall1.png",
    },
    {
      id: 10,
      name: "ION Orchard",
      link: "https://www.ionorchard.com/en/shop.html",
      pic: "./assets/CLmall10.png",
    },
    {
      id: 11,
      name: "Jewel Changi Air",
      link: "https://www.jewelchangiairport.com/",
      pic: "./assets/CLmall11.png",
    },
    {
      id: 12,
      name: "Junction 8",
      link: "https://www.capitaland.com/sg/malls/junction8/en.html",
      pic: "./assets/CLmall12.png",
    },
    {
      id: 13,
      name: "Kallang Wave",
      link: "https://www.sportshub.com.sg/shop-dine/stores",
      pic: "./assets/CLmall13.png",
    },
    {
      id: 14,
      name: "Lot One",
      link: "https://www.capitaland.com/sg/malls/lotone/en.html",
      pic: "./assets/CLmall14.png",
    },
    {
      id: 15,
      name: "Plaza Singapura",
      link: "https://www.capitaland.com/sg/malls/plazasingapura/en.html",
      pic: "./assets/CLmall15.png",
    },
    {
      id: 16,
      name: "Raffles City",
      link: "https://www.capitaland.com/sg/malls/rafflescity/en.html",
      pic: "./assets/CLmall16.png",
    },
    {
      id: 17,
      name: "Senkang Grand",
      link: "https://www.sengkanggrandmall.com.sg/en.html",
      pic: "./assets/CLmall17.png",
    },
    {
      id: 18,
      name: "SingPost Centre",
      link: "https://www.singpostcentre.com/",
      pic: "./assets/CLmall18.svg",
    },
    {
      id: 19,
      name: "Tampines Mall",
      link: "https://www.capitaland.com/sg/malls/tampinesmall/en.html",
      pic: "./assets/CLmall19.png",
    },
    {
      id: 20,
      name: "West Gate",
      link: "https://www.capitaland.com/sg/malls/westgate/en.html",
      pic: "./assets/CLmall20.png",
    },
  ];
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const MallsList = [
    {
      id: 1,
      name: "Hillion Mall",
      link: "https://www.hillionmall.com.sg/",
      pic: "./assets/mall1.png",
    },
  ];
  return (
    <>
      <div
        className="flex flex-wrap m-0 p-2 bg-sky-600 justify-center text-md
      xl:rounded-xl xl:text-lg text-bold xl:m-2 xl:justify-start"
      >
        <h1 className="mb-4 text-white font-bold text-xl mt-2 xl:ml-8 xl:text-2xl">
          CapitaLand Shopping Malls
        </h1>
        <ul className="flex flex-wrap gap-0 justify-center mb-6 xl:mb-4 xl:gap-0 xl:ml-6 xl:justify-start">
          {CentralMallsList.map(function (mall) {
            return (
              <li className="justify-items-center">
                <a href={mall.link} className="justify-center">
                  <div className="w-44 justify-items-center bg-gray-200 m-2 p-4 rounded-lg xl:rounded-xl xl:p-2 xl:w-48">
                    <img
                      src={mall.pic}
                      alt=""
                      className="h-8 m-0 xl:h-8 xl:mt-1"
                    />
                    <p className="mt-4">{mall.name}</p>
                  </div>
                </a>
              </li>
            );
          })}
        </ul>
      </div>
    </>
  );
};
export default Central