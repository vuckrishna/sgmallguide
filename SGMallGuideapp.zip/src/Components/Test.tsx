import React from 'react'
import Select from 'react-select'

const options = [
  { value: 'chocolate', label: 'Chocolate' },
  { value: 'strawberry', label: 'Strawberry' },
  { value: 'vanilla', label: 'Vanilla' }
]

const HandleChange = (e) => {
    if (e == 'chocolate'){}
}

const Test = () => (
  <Select options={options} onChange={HandleChange(options.values)} />

)


export default Test